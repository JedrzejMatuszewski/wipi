﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WatchShop.Data.EntityFramework.Migrations
{
    public partial class ExtendedOrders : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "ItemsPrice",
                table: "Orders",
                type: "decimal(7,2)",
                precision: 7,
                scale: 2,
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<int>(
                name: "ItemsQty",
                table: "Orders",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Orders_ItemsPrice",
                table: "Orders",
                column: "ItemsPrice");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_ItemsQty",
                table: "Orders",
                column: "ItemsQty");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Orders_ItemsPrice",
                table: "Orders");

            migrationBuilder.DropIndex(
                name: "IX_Orders_ItemsQty",
                table: "Orders");

            migrationBuilder.DropColumn(
                name: "ItemsPrice",
                table: "Orders");

            migrationBuilder.DropColumn(
                name: "ItemsQty",
                table: "Orders");
        }
    }
}
