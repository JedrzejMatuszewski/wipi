﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class ProductConfiguration : IEntityTypeConfiguration<Product>
    {
        public ProductConfiguration()
        {

        }
        public void Configure(EntityTypeBuilder<Product> builder)
        {
            builder.HasOne(x => x.Mark).WithMany().HasForeignKey(x => x.MarkId).OnDelete(DeleteBehavior.Cascade);
            builder.Property(x => x.Price).HasPrecision(7, 2);
            builder.Property(x => x.Description).HasMaxLength(5000);
            builder.HasIndex(x => x.Price);
            builder.HasIndex(x => x.Name);
            builder.HasIndex(x => x.Name);
            builder.HasIndex(x => x.Qty);
        }
    }
}
