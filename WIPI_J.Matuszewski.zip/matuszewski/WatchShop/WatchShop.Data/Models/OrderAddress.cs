﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WatchShop.Domain
{
    public class OrderAddress : Entity
    {
        public int OrderId { get; set; }
        public virtual Order Order { get; set; }
        public string StreetAndHomeNum { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
    }
}
