﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WatchShop.Domain
{
    public class Address : Entity
    {
        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }
        public string StreetAndHomeNum { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
    }
}
