﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Data;
using DevExtreme.AspNet.Data;
using WatchShop.Domain;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using System.Globalization;

namespace WatchShop.Application
{
    public class ShopService : IShopService
    {
        private readonly ICartItemRepository _cartItemRepository;
        private readonly ICartRepository _cartRepository;
        private readonly IGalleryRepository _galleryRepository;
        private readonly IMarkRepository _markRepository;
        private readonly IOrderItemRepository _orderItemRepository;
        private readonly IOrderRepository _orderRepository;
        private readonly IOrderStatusRepository _orderStatusRepository;
        private readonly IProductRepository _productRepository;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IAddressRepository _addressRepository;
        private readonly IOrderAddressRepository _orderAddressRepository;

        public ShopService(ICartItemRepository cartItemRepository, ICartRepository cartRepository,
            IGalleryRepository galleryRepository, IMarkRepository markRepository, 
            IOrderItemRepository orderItemRepository, IOrderRepository orderRepository,
            IOrderStatusRepository orderStatusRepository, IProductRepository productRepository,
            UserManager<ApplicationUser> userManager, IAddressRepository addressRepository, 
            IOrderAddressRepository orderAddressRepository, RoleManager<IdentityRole> roleManager
            )
        {
            this._cartItemRepository = cartItemRepository;
            this._cartRepository = cartRepository;
            this._galleryRepository = galleryRepository;
            this._markRepository = markRepository;
            this._orderItemRepository = orderItemRepository;
            this._orderRepository = orderRepository;
            this._orderStatusRepository = orderStatusRepository;
            this._productRepository = productRepository;
            this._userManager = userManager;
            this._addressRepository = addressRepository;
            this._orderAddressRepository = orderAddressRepository;
            this._roleManager = roleManager;
        }


        #region Tags
        public async Task<List<KeyValuePair<int,string>>> GetAllProductsTags()
        {
            var tags = new List<string>();
            var tagsKW = new List<KeyValuePair<int, string>>(); 

            var tagsStrigns = (await _productRepository.GetAllAsync()).Select(x => x.Tags).Where(x => !string.IsNullOrEmpty(x));

            foreach (var tagStr in tagsStrigns)
            {

                var splitted = tagStr.Split(";").Where(x => !string.IsNullOrEmpty(x)).Select(x => x.Trim());
                tags.AddRange(splitted);
            }

            var dist =  tags.Distinct().ToList();
            var count = 0;

            foreach (var item in dist)
            {
                count++;
                var pair = new KeyValuePair<int, string>(count, item.Trim());
                tagsKW.Add(pair);
            }

            return tagsKW;
        }
        #endregion

        #region Mark

        public async Task<object> MarkGet(DataSourceLoadOptionsBase loadOptions)
        {
            return await _markRepository.GetDataToList(loadOptions);
        }
        public async Task MarkPost(string values)
        {
            var mark = new Mark();
            JsonConvert.PopulateObject(values, mark);

            _markRepository.Add(mark);
            await _markRepository.SaveAsync();

        }
        public async Task MarkPut(int key, string values)
        {
            var mark = await _markRepository.GetSingleAsync(x => x.Id == key);
            JsonConvert.PopulateObject(values, mark);

            await _markRepository.SaveAsync();
        }
        public async Task MarkDelete(int key)
        {
            var mark = await _markRepository.GetSingleAsync(x => x.Id == key);
            _markRepository.Delete(mark);

            await _markRepository.SaveAsync();
        }
        #endregion

        #region OrderStatus
        public async Task<object> OrderStatusGet(DataSourceLoadOptionsBase loadOptions)
        {
            return await _orderStatusRepository.GetDataToList(loadOptions);
        }
        public async Task OrderStatusPost(string values)
        {
            var item = new OrderStatus();
            JsonConvert.PopulateObject(values, item);

            _orderStatusRepository.Add(item);
            await _orderStatusRepository.SaveAsync();

        }
        public async Task OrderStatusPut(int key, string values)
        {
            var item = await _orderStatusRepository.GetSingleAsync(x => x.Id == key);
            JsonConvert.PopulateObject(values, item);

            await _orderStatusRepository.SaveAsync();
        }
        public async Task OrderStatusDelete(int key)
        {
            var item = await _orderStatusRepository.GetSingleAsync(x => x.Id == key);
            _orderStatusRepository.Delete(item);

            await _orderStatusRepository.SaveAsync();
        }
        #endregion

        #region Address
        public async Task<object> AddressGet(DataSourceLoadOptionsBase loadOptions)
        {
            return await _addressRepository.GetDataToList(loadOptions);
        }
        public async Task<object> AddressGetForUser(DataSourceLoadOptionsBase loadOptions, string userId)
        {
            return await _addressRepository.GetDataToListForUser(loadOptions, userId);
        }
        public async Task AddressPost(string values, string userId)
        {
            var item = new Address();
            JsonConvert.PopulateObject(values, item);
            item.UserId = userId;

            _addressRepository.Add(item);
            await _addressRepository.SaveAsync();

        }
        public async Task AddressPut(int key, string values)
        {
            var item = await _addressRepository.GetSingleAsync(x => x.Id == key);
            JsonConvert.PopulateObject(values, item);

            await _addressRepository.SaveAsync();
        }
        public async Task AddressDelete(int key)
        {
            var item = await _addressRepository.GetSingleAsync(x => x.Id == key);
            _addressRepository.Delete(item);

            await _addressRepository.SaveAsync();
        }
        #endregion

        #region Cart
        public async Task<object> CartItemsGet(DataSourceLoadOptionsBase loadOptions, int cartId)
        {
            return await _cartItemRepository.GetDataToListForChart(loadOptions, cartId);
        }
        public async Task CartItemsPut(int key, string values)
        {
            var item = await _cartItemRepository.GetSingleAsync(x => x.Id == key);
            JsonConvert.PopulateObject(values, item);

            await _cartItemRepository.SaveAsync();
        }
        public async Task CartItemsDelete(int key)
        {
            var item = await _cartItemRepository.GetSingleAsync(x => x.Id == key);
            _cartItemRepository.Delete(item);

            await _cartItemRepository.SaveAsync();
        }

        public async Task CartAllItemsDelete(int cartId)
        {
            _cartItemRepository.DeleteWhere(x=> x.CartId == cartId);

            await _cartItemRepository.SaveAsync();
        }

        public async Task<string> CartTotalValue(int cartId)
        {
            decimal sum = 0;
            var specifier = "C";
            var culture = CultureInfo.CreateSpecificCulture("en-US");

            var cartItems = await _cartItemRepository.GetAllAsync(x => x.CartId == cartId);
            foreach (var item in cartItems)
            {
                var product = await _productRepository.GetSingleAsync(x => x.Id == item.ProductId);
                if(product != null)
                {
                    sum += product.Price * item.Qty;
                }
                
            }
            return sum.ToString(specifier, culture);
        }
        #endregion
        
        #region ShopOperations
        public async Task AddNewProduct(ProductAddVM model)
        {
            var mark = await _markRepository.GetSingleAsync(x => x.Id == model.MarkId);

            var product = new Product
            {
                Name = model.Name,
                Description = model.Description,
                MarkId = mark.Id,
                Mark = mark,
                Price = model.Price,
                Qty = model.Qty,
                Tags = model.Tags
            };

            _productRepository.Add(product);
            await _productRepository.SaveAsync();

            var galleryList = new List<Gallery>();
            foreach (var name in model.PhotoNames)
            {
                var gallery = new Gallery
                {
                    ProductId = product.Id,
                    ImageUrl = name
                };

                galleryList.Add(gallery);
            }

            _galleryRepository.AddRange(galleryList);
            await _galleryRepository.SaveAsync();
        }

        public async Task EditProduct(ProductEditVM model)
        {
            var mark = await _markRepository.GetSingleAsync(x => x.Id == model.MarkId);

            var product = await _productRepository.GetSingleAsync(x => x.Id == model.ProductId);

            product.Name = model.Name;
            product.Description = model.Description;
            product.MarkId = mark.Id;
            product.Mark = mark;
            product.Price = model.Price;
            product.Qty = model.Qty;
            product.Tags = model.Tags;


            _productRepository.Edit(product);
            await _productRepository.SaveAsync();


            if (model.IsGaleryUpdate)
            {
                _galleryRepository.DeleteWhere(x => x.ProductId == model.ProductId);
                await _galleryRepository.SaveAsync();
                var galleryList = new List<Gallery>();
                foreach (var name in model.PhotoNames)
                {
                    var gallery = new Gallery
                    {
                        ProductId = product.Id,
                        ImageUrl = name
                    };

                    galleryList.Add(gallery);
                }

                _galleryRepository.AddRange(galleryList);
                await _galleryRepository.SaveAsync();
            }

            
        }

        public async Task<ProductEditVM> GetProductEditVM(int productId)
        {
            var product = await _productRepository.GetSingleAsync(x => x.Id == productId);

            if (product == null)
            {
                throw new Exception("Product not found");
            }

            var model = new ProductEditVM
            {
                ProductId = productId,
                Name = product.Name,
                Description = product.Description,
                MarkId = product.MarkId,
                Price = product.Price,
                Qty = product.Qty,
                Marks = await _markRepository.GetDataToModelEnumBinder(),
                Tags = product.Tags
            };

            return model;
        }

        public async Task<ProductDetailsVM> ProductGetAll()
        {
            var porductVmList = new List<ProductVM>();

            var products = await _productRepository.GetAllAsync();

            foreach (var item in products)
            {
                var galleryList = (await _galleryRepository.GetAllAsync(x => x.ProductId == item.Id)).Select(x => x.ImageUrl);
                var mark = await _markRepository.GetSingleAsync(x => x.Id == item.MarkId);

                var porductVM = new ProductVM
                {
                    Id = item.Id,
                    Name = item.Name,
                    Description = item.Description,
                    Qty = item.Qty,
                    Price = item.Price,
                    Mark = mark,
                    PhotoNames = galleryList
                };

                porductVmList.Add(porductVM);
            }

            return new ProductDetailsVM { Products = porductVmList };
        }
        public async Task<object> ProductGetAll(DataSourceLoadOptionsBase loadOptions)
        {
            return await _productRepository.GetDataToList(loadOptions);
        }

        public async Task<ProductDetailsVM> ProductGetAll(string searchString, int priceFrom, int priceTo, string markString, string tagString)
        {
            var porductVmList = new List<ProductVM>();
            var products = await _productRepository.GetAllAsync();

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                products = products.Where(x => x.Name.ToLower().Contains(searchString.ToLower()) ||
                                               x.Description.ToLower().Contains(searchString.ToLower())).ToList();

                var markIds = (await _markRepository.GetAllAsync(x => x.Name.ToLower().Contains(searchString.ToLower()))).Select(x => x.Id);
                var newProducts = await _productRepository.GetAllAsync(x => markIds.Contains(x.MarkId));
                products.AddRange(newProducts);
                products = products.Distinct().ToList();
            }

            //Price
            products = products.Where(x => x.Price >= priceFrom && x.Price <= priceTo).ToList();

            //MarksSelected
            if (!string.IsNullOrEmpty(markString))
            {
                var marks = markString.Split(";").Where(x => !string.IsNullOrEmpty(x)).Select(x => x.Trim());

                if (marks.Any())
                {
                    var mIds = _markRepository.GetAll(x => marks.Contains(x.Name)).Select(x => x.Id);
                    products = products.Where(x => mIds.Contains(x.MarkId)).ToList();
                }
            }

            //TagsSelected
            if (!string.IsNullOrEmpty(tagString))
            {
                var tags = tagString.Split(";").Where(x => !string.IsNullOrEmpty(x)).Select(x=> x.Trim());
                if (tags.Any())
                {
                    products = products.Where(x => !string.IsNullOrEmpty(x.Tags) && tags.Any(t => x.Tags.Contains(t))).ToList();
                }
            }

            foreach (var item in products)
            {
                var galleryList = (await _galleryRepository.GetAllAsync(x => x.ProductId == item.Id)).Select(x => x.ImageUrl);
                var mark = await _markRepository.GetSingleAsync(x => x.Id == item.MarkId);


                if (item.Description != null && item.Description.Length > 115)
                {
                    item.Description = item.Description.Substring(0, 115) + "...";
                }

                var porductVM = new ProductVM
                {
                    Id = item.Id,
                    Name = item.Name,
                    Description = item.Description,
                    Qty = item.Qty,
                    Price = item.Price,
                    Mark = mark,
                    PhotoNames = galleryList,
                    CreatedTime = item.CreatedDate,
                    Tags = item.Tags,
                    TagsList = item?.Tags?.Split(";")?.Where(x => !string.IsNullOrEmpty(x)).Select(x => x.Trim()) ?? new List<string>()
                };

                porductVmList.Add(porductVM);
            }

            var marksToLookup = (await _markRepository.GetAllAsync()).Select(x => x.Name).ToList();

            return new ProductDetailsVM { Products = porductVmList, MarksToLookup = marksToLookup, Count = (porductVmList?.Count ?? 0) };
        }

        public async Task<ProductVM> GetProduct(int id)
        {
            var product = await _productRepository.GetSingleAsync(x => x.Id == id);
            var mark = await _markRepository.GetSingleAsync(x => x.Id == product.MarkId);
            var galleryList = (await _galleryRepository.GetAllAsync(x => x.ProductId == product.Id)).Select(x => x.ImageUrl);

            var description = product.Description;
            var shortDescription = string.Empty;

            if (description != null)
            {
                shortDescription = description;
                if (description.Length > 115)
                {
                    shortDescription = description.Substring(0, 115) + "...";
                }
            }

            var model = new ProductVM
            {
                Id = product.Id,
                Name = product.Name,
                Description = product.Description,
                DescriptionShort = shortDescription,
                Mark = mark,
                Price = product.Price,
                Qty = product.Qty,
                PhotoNames = galleryList,
                TagsList = product?.Tags?.Split(";")?.Where(x => !string.IsNullOrEmpty(x)).Select(x => x.Trim()) ?? new List<string>()
            };
            return model;
        }

        public async Task AddToCart(int id, int qty, string userId)
        {
            var cart = await _cartRepository.GetSingleAsync(x => x.UserId == userId);

            if (cart == null)
            {
                throw new Exception("Nie znaleziono koszyka");
            }

            var cartItemExist = await _cartItemRepository.GetSingleAsync(x => x.CartId == cart.Id && x.ProductId == id);
            if (cartItemExist != null)
            {
                cartItemExist.Qty += qty;
            }
            else
            {
                var cartItem = new CartItem
                {
                    CartId = cart.Id,
                    ProductId = id,
                    Qty = qty
                };

                _cartItemRepository.Add(cartItem);
            }


            await _cartItemRepository.SaveAsync();
        }

        public async Task<object> GetUserAddresses(DataSourceLoadOptionsBase loadOptions, string userId)
        {
            return await _addressRepository.GetDataToListForUser(loadOptions, userId);
        }

        public async Task<object> GetAddressById(DataSourceLoadOptionsBase loadOptions, int addressId)
        {
            return await _addressRepository.GetAddressById(loadOptions, addressId);
        }

        

        #endregion

        #region Orders
        public async Task<object> OrdersGet(DataSourceLoadOptionsBase loadOptions)
        {
            return await _orderRepository.GetDataToList(loadOptions);
        }
        public async Task<object> OrdersGetForUser(DataSourceLoadOptionsBase loadOptions, string userId)
        {
            return await _orderRepository.GetDataToListForUser(loadOptions, userId);
        }
        public async Task OrdersDelete(int key)
        {
            var item = await _orderRepository.GetSingleAsync(x => x.Id == key);
            _orderRepository.Delete(item);

            await _orderRepository.SaveAsync();
        }

        public async Task<OrderVM> OrderDetalis(int orderId)
        {
            var order = await _orderRepository.GetSingleAsync(x => x.Id == orderId);
            if(order == null)
            {
                throw new Exception("Nie znaleziono zamowienia");
            }

            var user = await _userManager.FindByIdAsync(order.UserId);

            var orderItems = await _orderItemRepository.GetAllAsync(x => x.OrderId == orderId);
            foreach (var item in orderItems)
            {
                var product = await _productRepository.GetSingleAsync(x => x.Id == item.ProductId);
                var mark = await _markRepository.GetSingleAsync(x => x.Id == product.MarkId);
                product.Mark = mark;
                item.Product = product;
            }

            var orderAddress = await _orderAddressRepository.GetSingleAsync(x => x.OrderId == orderId);

            var statuses = await _orderStatusRepository.GetEnumModelBinder();

            var model = new OrderVM
            {
                Order = order,
                Items = orderItems,
                Adress = orderAddress,
                User = user ?? new ApplicationUser(),
                Statuses = statuses
            };

            return model;
        }

        public async Task<object> GetOrdersDataToListForOrder(DataSourceLoadOptionsBase loadOptions, int orderId)
        {
            return await _orderItemRepository.GetDataToListForOrder(loadOptions, orderId);
        }

        public async Task<Order> CreateOrder(NewOrderVM model)
        {
            //var role = new IdentityRole();
            //role.Name = "AdminRole";
            //await _roleManager.CreateAsync(role);

            //var usr = await _userManager.FindByIdAsync(model.UserId);

            //await _userManager.AddToRoleAsync(usr, "AdminRole");

            var status = await _orderStatusRepository.GetSingleAsync(x => x.Id == 1);

            var order = new Order
            {
                //User = model.User,
                UserId = model.UserId,
                OrderStatus = status,
                CreatedDate = DateTime.Now
            };
            _orderRepository.Add(order);
            await _orderRepository.SaveAsync();

            var orderAddress = new OrderAddress
            {
                //Order = order,
                OrderId = order.Id,
                StreetAndHomeNum = model.StreetAndHome,
                City = model.City,
                ZipCode = model.ZipCode
            };
            _orderAddressRepository.Add(orderAddress);
            await _orderAddressRepository.SaveAsync();

            var cartItems = await _cartItemRepository.GetAllAsync(x => x.CartId == model.CartId);
            var orderItems = new List<OrderItem>();

            decimal orderItemsPrice = 0;
            int orderItemsQty = 0;

            foreach (var cartItem in cartItems)
            {
                var product = await _productRepository.GetSingleAsync(x => x.Id == cartItem.ProductId);

                var orderItem = new OrderItem
                {
                    //Order = order,
                    OrderId = order.Id,
                    Product = product,
                    ProductId = product.Id,
                    Qty = cartItem.Qty,
                    Price = product.Price
                };

                orderItems.Add(orderItem);

                orderItemsPrice += (product.Price * cartItem.Qty);
                orderItemsQty += cartItem.Qty;

            }
            _orderItemRepository.AddRange(orderItems);
            await _orderItemRepository.SaveAsync();

            order.ItemsPrice = orderItemsPrice;
            order.ItemsQty = orderItemsQty;
            await _orderRepository.SaveAsync();


            _cartRepository.DeleteWhere(x => x.Id == model.CartId);
            await _cartRepository.SaveAsync();

            return order;
        }

        public async Task EditOrderStatus(int orderId, int statusId)
        {
            var status = await _orderStatusRepository.GetSingleAsync(x => x.Id == statusId);
            var order = await _orderRepository.GetSingleAsync(x => x.Id == orderId);
            if(order == null || status == null)
            {
                return;
            }

            if(order.OrderStatusId == status.Id)
            {
                return;
            }

            order.OrderStatusId = status.Id;
            order.ModifiedDate = DateTime.Now;

            if(status.Id == 2)
            {
                order.ShipmentDate = DateTime.Now;
            }

            await _orderRepository.SaveAsync();
        }
        #endregion


       

       
    }
}