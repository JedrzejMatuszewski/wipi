﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using WatchShop.Domain;
using X.PagedList;

namespace WatchShop.Application
{
    public class ProductDetailsVM
    {
        public IPagedList<ProductVM> ProductsPaged { get; set; }
        public IEnumerable<ProductVM> Products { get; set; }

        public IEnumerable<string> MarksToLookup { get; set; }

        public IEnumerable<KeyValuePair<int, string>> TagsToLookup { get; set; }

        public int Count { get; set; }
    }

    public class ProductVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string DescriptionShort { get; set; }
        public string Tags { get; set; }
        public IEnumerable<string> TagsList { get; set; }
        public int Qty { get; set; }
        public decimal Price { get; set; }
        public Mark Mark { get; set; }
        public IEnumerable<string> PhotoNames { get; set; }
        public DateTime CreatedTime { get; set; }
    }
}
