﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using X.PagedList;

namespace WatchShop.Application
{
    public class IndexVM
    {
        public string SearchString { get; set; }
        public int PriceFrom { get; set; }
        public int PriceTo { get; set; }
        public string MarkSelected { get; set; }
        public string TagsSelected { get; set; }
        public string OrderBy { get; set; }
        public int Page { get; set; }
    }
}
