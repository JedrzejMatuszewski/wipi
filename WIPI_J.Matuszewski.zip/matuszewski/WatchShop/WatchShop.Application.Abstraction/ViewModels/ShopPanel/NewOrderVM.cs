﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Application
{
    public class NewOrderVM
    {
        [Required]
        public ApplicationUser User { get; set; }
        [Required]
        public string UserId { get; set; }
        [Required]
        public int CartId { get; set; }
        [Required]
        public string StreetAndHome { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string ZipCode { get; set; }


    }
}
