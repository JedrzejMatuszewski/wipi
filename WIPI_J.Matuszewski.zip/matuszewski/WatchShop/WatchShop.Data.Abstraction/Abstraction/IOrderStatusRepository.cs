﻿using DevExtreme.AspNet.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Application;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public interface IOrderStatusRepository : IRepository<OrderStatus>
    {
        Task<object> GetDataToList(DataSourceLoadOptionsBase loadOptions);

        Task<List<EnumModelBinder<int>>> GetEnumModelBinder();
    }
}
