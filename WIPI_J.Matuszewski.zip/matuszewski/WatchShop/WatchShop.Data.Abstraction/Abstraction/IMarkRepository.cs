﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DevExtreme.AspNet.Data;
using WatchShop.Application;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public interface IMarkRepository : IRepository<Mark>
    {
        Task<object> GetDataToList(DataSourceLoadOptionsBase loadOptions);
        Task<List<EnumModelBinder<int>>> GetDataToModelEnumBinder();
    }
}
