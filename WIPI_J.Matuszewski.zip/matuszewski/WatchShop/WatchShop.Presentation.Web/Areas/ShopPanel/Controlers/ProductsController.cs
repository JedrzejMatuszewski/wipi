﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WatchShop.Application;
using WatchShop.Data;
using WatchShop.Presentation.Web.Utils;
using Microsoft.AspNetCore.Identity;
using System;
using WatchShop.Domain;
using System.Linq;
using X.PagedList;

namespace WatchShop.Presentation
{
    [Area(AreaNames.ShopPanel)]
    public class ProductsController : Controller
    {
        private readonly IShopService _shopService;
        private readonly UserManager<ApplicationUser> _userManager;
        public ProductsController(IShopService shopService, UserManager<ApplicationUser> userManager)
        {
            this._shopService = shopService;
            this._userManager = userManager;
        }

        public async Task<IActionResult> Index(IndexVM vm)
        {
            if (vm.PriceTo == 0)
                vm.PriceTo = 99999;

            if (string.IsNullOrEmpty(vm.OrderBy))
                vm.OrderBy = "Added Date";

            if(vm.Page == 0)
                vm.Page = 1;

            ViewData["SearchString"] = vm.SearchString;
            ViewData["PriceFrom"] = vm.PriceFrom;
            ViewData["PriceTo"] = vm.PriceTo;
            ViewData["MarksSelected"] = vm.MarkSelected;
            ViewData["TagsSelected"] = vm.TagsSelected;
            ViewData["OrderBy"] = vm.OrderBy;
            ViewData["Page"] = vm.Page;

            var model = await _shopService.ProductGetAll(vm.SearchString, vm.PriceFrom, vm.PriceTo, vm.MarkSelected, vm.TagsSelected);

            switch (vm.OrderBy)
            {
                case "Added Date":
                    model.Products = model.Products.OrderByDescending(x => x.CreatedTime);
                    break;
                case "Name":
                    model.Products = model.Products.OrderBy(x => x.Name);
                    break;
                case "Price Lower":
                    model.Products = model.Products.OrderBy(x => x.Price);
                    break;
                case "Price Higher":
                    model.Products = model.Products.OrderByDescending(x => x.Price);
                    break;
                default:
                    break;
            }

            var pageSize = 9;
            model.ProductsPaged = await model.Products.ToPagedListAsync(vm.Page, pageSize);
            if(model.ProductsPaged.Count == 0)
            {
                ViewData["Page"] = 1;
                model.ProductsPaged = await model.Products.ToPagedListAsync(1, pageSize);
            }

            model.TagsToLookup = await _shopService.GetAllProductsTags();

            return View(model);
        }

        public async Task<IActionResult> Detalis(int? id)
        {
            if(id == null)
            {
                return BadRequest();
            }
            var model = await _shopService.GetProduct((int)id);
            return View(model);
        }

        public async Task<IActionResult> AddToCart(int id, int qty)
        {
            try
            {
                var user = await _userManager.GetUserAsync(HttpContext.User);
                await _shopService.AddToCart(id, qty, user.Id);
                TempData["message"] = "Item has been added to cart";
                return RedirectToAction("Index");
            }
            catch(Exception)
            {
                return BadRequest();
            }
        }
    }
}
