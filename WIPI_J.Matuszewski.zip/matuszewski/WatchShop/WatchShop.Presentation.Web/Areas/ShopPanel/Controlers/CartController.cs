﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WatchShop.Application;
using WatchShop.Data;
using WatchShop.Presentation.Web.Utils;
using Microsoft.AspNetCore.Identity;
using System;
using DevExtreme.AspNet.Data;
using WatchShop.Domain;

namespace WatchShop.Presentation
{
    [Area(AreaNames.ShopPanel)]
    public class CartController : Controller
    {
        private readonly IShopService _shopService;
        private readonly UserManager<ApplicationUser> _userManager;
        public CartController(IShopService shopService, UserManager<ApplicationUser> userManager)
        {
            this._shopService = shopService;
            this._userManager = userManager;
        }

        #region Chart
        public async Task<IActionResult> Index(CartVM model)
        {
            if (ModelState.IsValid)
            {
                return View(model);
            }
            return BadRequest("Error");
        }

        [HttpGet]
        public async Task<IActionResult> CartItemsGetForUser(DataSourceLoadOptionsBase loadOptions, int cartId)
        {
            return Json(await _shopService.CartItemsGet(loadOptions, cartId));
        }

        [HttpPut]
        public async Task<IActionResult> CartItemsPut(int key, string values)
        {
            try
            {
                await _shopService.CartItemsPut(key, values);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }

        [HttpDelete]
        public async Task<IActionResult> CartItemsDelete(int key)
        {
            try
            {
                await _shopService.CartItemsDelete(key);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }


        [HttpPost]
        public async Task<object> CartTotalValue(int cartId)
        {
            return Json(await _shopService.CartTotalValue(cartId));
        }

        [HttpPost]
        public async Task<IActionResult> CartAllItemsDelete(int cartId)
        {
            try
            {
                await _shopService.CartAllItemsDelete(cartId);
                return Json(true);
                //return RedirectToAction("Index", "Cart", new { area = AreaNames.ShopPanel, cartId = cartId });
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }

        #endregion



    }
}