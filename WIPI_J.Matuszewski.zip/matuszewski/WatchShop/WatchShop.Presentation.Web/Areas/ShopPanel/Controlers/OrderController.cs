﻿using DevExtreme.AspNet.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WatchShop.Application;
using WatchShop.Domain;
using WatchShop.Presentation.Web.Utils;

namespace WatchShop.Presentation
{
    [Area(AreaNames.ShopPanel)]
    public class OrderController : Controller
    {
        private readonly IShopService _shopService;
        private readonly UserManager<ApplicationUser> _userManager;

        public OrderController(IShopService shopService, UserManager<ApplicationUser> userManager)
        {
            this._shopService = shopService;
            this._userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        //[HttpGet]
        [Route("[controller]/[action]/{orderId?}")]
        public async Task<IActionResult> Detalis(int? orderId)
        {
            if (orderId == null)
            {
                return BadRequest("Wrong data");
            }

            var model = await _shopService.OrderDetalis((int)orderId);
            model.ReqestUser = await _userManager.GetUserAsync(HttpContext.User);
            return View(model);
        }


        //public async Task<IActionResult> GetUserAddresses(DataSourceLoadOptionsBase loadOptions, string userId)
        //{
        //    return Ok();//Json(await _shopService.GetUserAddresses)
        //}

        [HttpPost]
        public async Task<IActionResult> GetAddressById(DataSourceLoadOptionsBase loadOptions, int addressId)
        {
            return Json(await _shopService.GetAddressById(loadOptions, addressId));
        }

        [HttpPost] 
        public async Task<IActionResult> CreateOrder(NewOrderVM model)
        {
            Order order = new Order();
            if (!ModelState.IsValid)
            {
                return BadRequest("Wystąpił błąd");
            }

            try
            {
                order = await _shopService.CreateOrder(model);
            }catch(Exception)
            {
                return BadRequest("Wystąpił błąd");
            }


            TempData["message"] = "Order has been submited";                     // Pobierz orderID
            TempData["Orderessage"] = "Order has been submited";                     // Pobierz orderID
            return RedirectToAction("Detalis", new { area = AreaNames.ShopPanel, orderId = order.Id});

        }


        [HttpGet]
        public async Task<IActionResult> OrdersGetAll(DataSourceLoadOptionsBase loadOptions)
        {
            return Json(await _shopService.OrdersGet(loadOptions));
        }

        [HttpGet]
        public async Task<IActionResult> OrdersGetForUser(DataSourceLoadOptionsBase loadOptions)
        {
            ApplicationUser user = null;
            if (HttpContext.User != null)
            {
                user = await _userManager.GetUserAsync(HttpContext.User);
            }

            if (user == null)
            {
                return BadRequest("Nie znaleziono użytkownika");
            }

            return Json(await _shopService.OrdersGetForUser(loadOptions, user.Id));
        }
        
        [HttpDelete]
        public async Task<IActionResult> AddressDelete(int key)
        {
            try
            {
                await _shopService.OrdersDelete(key);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        

        public async Task<IActionResult> GetOrdersDataToListForOrder(DataSourceLoadOptionsBase loadOptions, int orderId)
        {
            return Json(await _shopService.GetOrdersDataToListForOrder(loadOptions, orderId));
        }


        [HttpPost]
        public async Task<IActionResult> EditOrderStatus(int? orderId, int? statusId)
        {
            if(orderId ==null|| statusId == null)
            {
                return BadRequest("Error");
            }
            await _shopService.EditOrderStatus((int)orderId, (int)statusId);


            TempData["message"] = "Status edited";

            return RedirectToAction("Detalis", new { orderId = (int)orderId });
        }


    }
}
