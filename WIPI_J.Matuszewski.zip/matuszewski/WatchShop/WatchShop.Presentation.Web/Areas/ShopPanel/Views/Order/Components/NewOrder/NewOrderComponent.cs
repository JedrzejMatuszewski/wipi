﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WatchShop.Application;
using WatchShop.Data;
using WatchShop.Domain;

namespace WatchShop.Presentation.Web.Areas.ShopPanel.Views.Order.Components.NewOrder
{
    [ViewComponent(Name = "NewOrder")]
    public class NewOrderComponent : ViewComponent
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ICartItemRepository _cartItemRepository;
        public NewOrderComponent(UserManager<ApplicationUser> userManager,
            ICartItemRepository cartItemRepository)
        {
            this._userManager = userManager;
            this._cartItemRepository = cartItemRepository;
        }

        public async Task<IViewComponentResult> InvokeAsync(NewOrderVM model)
        {
            var user = await _userManager.GetUserAsync(HttpContext.User);
            model.User = user;
            model.UserId = user.Id;

            var item = await _cartItemRepository.GetSingleAsync(x => x.CartId == model.CartId);

            if(item != null)
            {
                return View("/Areas/ShopPanel/Views/Order/Components/NewOrder/NewOrder.cshtml", model);
            }
            else
            {
                return View("/Areas/ShopPanel/Views/Order/Components/NewOrder/Empty.cshtml");
            }
        }

    }
}


/*
 using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WatchShop.Application;
using WatchShop.Data;
using WatchShop.Domain;

namespace WatchShop.Presentation.Web.Areas.ShopPanel.Views.Components
{
    [ViewComponent(Name = "CartIcon")]
    public class CartIconComponent : ViewComponent
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly ICartItemRepository _cartItemRepository;
        private readonly ICartRepository _cartRepository;

        public CartIconComponent(UserManager<IdentityUser> userManager, 
            ICartItemRepository cartItemRepository, ICartRepository cartRepository)
        {
            this._userManager = userManager;
            this._cartItemRepository = cartItemRepository;
            this._cartRepository = cartRepository;

        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            IdentityUser user = null;

            if(HttpContext.User != null)
            {
                user = await _userManager.GetUserAsync(HttpContext.User);
            }

            if(user == null)
            {
                return View("/Areas/ShopPanel/Views/Products/Components/CartIcon/CartIcon.cshtml", new CartVM { CartId = 0, ItemsCount = 77, UserId = "" });
            }

            var cart = await _cartRepository.GetSingleAsync(x => x.UserId == user.Id);
            if(cart == null)
            {
                cart = new Cart
                {
                    UserId = user.Id,
                    User = user
                };

                _cartRepository.Add(cart);
                await _cartRepository.SaveAsync();
            }

            var cartItems = await _cartItemRepository.GetAllAsync(x => x.CartId == cart.Id);
            var count = 0;
            foreach (var item in cartItems)
            {
                count += item.Qty;
            }

            return View("/Areas/ShopPanel/Views/Products/Components/CartIcon/CartIcon.cshtml", new CartVM()
            {
                UserId = user.Id,
                CartId = cart.Id,
                ItemsCount = count
            });
        }
    }
}




 */