﻿namespace WatchShop.Presentation.Web.Utils
{
    public static class AreaNames
    {
        public const string ShopPanel = "ShopPanel";
        public const string UserPanel = "UserPanel";
        public const string AdminPanel = "AdminPanel";
    }
}
