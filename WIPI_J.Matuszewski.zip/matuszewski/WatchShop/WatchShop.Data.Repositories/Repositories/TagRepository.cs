﻿using DevExtreme.AspNet.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Application;
using WatchShop.Data;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class TagRepository : Repository<Tag, ApplicationDbContext>, ITagRepository
    {
        public TagRepository(ApplicationDbContext context) : base(context)
        {

        }


        public async Task<object> GetDataToList(DataSourceLoadOptionsBase loadOptions)
        {
            var internalQuery = _dbset.Select(x => new
            {
                Id = x.Id,
                Name = x.Name
            });
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }

        public async Task<List<EnumModelBinder<int>>> GetDataToModelEnumBinder()
        {
            var data = await _dbset.Select(x => new EnumModelBinder<int>
            {
                Value = x.Id,
                Text = x.Name
            }).ToListAsync();
            return data;
        }

    }
}
