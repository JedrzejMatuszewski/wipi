﻿using DevExtreme.AspNet.Data;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Data;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class CartItemRepository : Repository<CartItem, ApplicationDbContext>, ICartItemRepository
    {
        public CartItemRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<object> GetDataToListForChart(DataSourceLoadOptionsBase loadOptions, int chartId)
        {
            var specifier = "C";
            var culture = CultureInfo.CreateSpecificCulture("en-US");

            var internalQuery = _dbset.Where(x => x.CartId == chartId).Select(x => new
            {
                Id = x.Id,
                ProductName = x.Product.Name,
                ProductId = x.Product.Id,
                MarkName = x.Product.Mark.Name,
                Price = x.Product.Price.ToString(specifier, culture),
                Qty = x.Qty,
                TotalPrice = (x.Qty * x.Product.Price).ToString(specifier, culture)
            });
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }
    }   
}
