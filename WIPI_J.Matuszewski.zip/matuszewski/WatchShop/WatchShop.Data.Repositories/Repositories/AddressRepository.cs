﻿using DevExtreme.AspNet.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class AddressRepository : Repository<Address, ApplicationDbContext>, IAddressRepository
    {
        public AddressRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<object> GetDataToList(DataSourceLoadOptionsBase loadOptions)
        {
            var internalQuery = _dbset.Select(x => new
            {
                x.Id,
                x.UserId,
                x.StreetAndHomeNum,
                x.City,
                x.ZipCode
            });
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }

        public async Task<object> GetDataToListForUser(DataSourceLoadOptionsBase loadOptions, string userId)
        {
            var internalQuery = _dbset.Where(x => x.UserId == userId).Select(x => new
            {
                x.Id,
                x.UserId,
                x.StreetAndHomeNum,
                x.City,
                x.ZipCode,
                DisplayValue = x.StreetAndHomeNum + " " + x.City + " " + x.ZipCode
            });
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }

        public async Task<object> GetAddressById(DataSourceLoadOptionsBase loadOptions, int id)
        {
            var internalQuery = _dbset.Where(x => x.Id == id).Select(x => new
            {
                x.Id,
                x.UserId,
                x.StreetAndHomeNum,
                x.City,
                x.ZipCode
            });
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }
    }
}