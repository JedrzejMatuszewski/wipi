﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class OrderAddressRepository : Repository<OrderAddress, ApplicationDbContext>, IOrderAddressRepository
    {
        public OrderAddressRepository(ApplicationDbContext context) : base(context)
        {
        }
    }
}
