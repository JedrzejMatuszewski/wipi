﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Data;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class CartRepository : Repository<Cart, ApplicationDbContext>, ICartRepository
    {
        public CartRepository(ApplicationDbContext context) : base(context)
        {
        }

    }   
}
