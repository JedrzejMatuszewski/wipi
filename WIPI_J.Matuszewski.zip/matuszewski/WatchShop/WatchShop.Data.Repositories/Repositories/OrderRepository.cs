﻿using DevExtreme.AspNet.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class OrderRepository : Repository<Order, ApplicationDbContext>, IOrderRepository
    {
        public OrderRepository(ApplicationDbContext context) : base(context)
        {

        }

        public async Task<object> GetDataToList(DataSourceLoadOptionsBase loadOptions)
        {
            var internalQuery = _dbset.Select(x => new
            {
                Id = x.Id,
                UserId = x.UserId,
                UserName = x.User.FirstName + " " + x.User.LastName,
                Email = x.User.Email,
                Status = x.OrderStatus.Status,
                CreatedDate = x.CreatedDate,
                ShipmentDate = x.ShipmentDate,
                ItemsQty = x.ItemsQty,
                Price = x.ItemsPrice
            }) ;
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }

        public async Task<object> GetDataToListForUser(DataSourceLoadOptionsBase loadOptions, string userId)
        {
            var internalQuery = _dbset.Where(x => x.UserId == userId).Select(x => new
            {
                Id = x.Id,
                UserId = x.UserId,
                Email = x.User.Email,
                Status = x.OrderStatus.Status,
                CreatedDate = x.CreatedDate,
                ShipmentDate = x.ShipmentDate,
                ItemsQty = x.ItemsQty,
                Price = x.ItemsPrice
            });
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }

        public async Task<object> GetDataToList()
        {
            var internalQuery = _dbset.Select(x => new
            {
                Id = x.Id,
                UserId = x.UserId,
                UserName = x.User.FirstName + " " + x.User.LastName,
                Email = x.User.Email,
                Status = x.OrderStatus.Status,
                CreatedDate = x.CreatedDate,
                ShipmentDate = x.ShipmentDate,
                ItemsQty = x.ItemsQty,
                Price = x.ItemsPrice
            }).ToList();
            return internalQuery;
        }
    }
}
